from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from django.views.decorators.http import require_GET
import random
import string

@require_GET
def generate_password(request):
    length = int(request.GET.get('length', 12))
    password = generate_password_helper(length)
    return JsonResponse({'password': password})

def generate_password_helper(length=12):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

